import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import { LazyMotion, domAnimation } from 'motion/react';
import ScrollToTop from './components/ScrollToTop';
import WhatsAppButton from "./components/WhatsAppButton";
import UtmTracker from "./components/UtmTracker";
import Home from './pages/Home';
import Obrigado from './pages/Obrigado';

const PrivacyPolicy = lazy(() => import('./pages/PrivacyPolicy'));
const TermsOfUse = lazy(() => import('./pages/TermsOfUse'));
const ReservaDosPassaros2 = lazy(() => import('./pages/ReservaDosPassaros2'));
const PrimeClubItaborai = lazy(() => import('./pages/PrimeClubItaborai'));
const FloresDeMaio = lazy(() => import('./pages/FloresDeMaio'));
const SolarDaTrindade = lazy(() => import('./pages/SolarDaTrindade'));
const ResidencialFlorescer = lazy(() => import('./pages/ResidencialFlorescer'));
const ConquistaOceanica = lazy(() => import('./pages/ConquistaOceanica'));
const McmvItaborai = lazy(() => import('./pages/McmvItaborai'));
const McmvSaoGoncalo = lazy(() => import('./pages/McmvSaoGoncalo'));
const Financiamento = lazy(() => import('./pages/Financiamento'));
const FgtsMcmv = lazy(() => import('./pages/FgtsMcmv'));
const SubsidioMcmv = lazy(() => import('./pages/SubsidioMcmv'));
const RendaMcmv = lazy(() => import('./pages/RendaMcmv'));
const DocumentosMcmv = lazy(() => import('./pages/DocumentosMcmv'));
const Sobre = lazy(() => import('./pages/Sobre'));
const NotFound = lazy(() => import('./pages/NotFound'));

export default function App() {
  if (typeof window !== 'undefined' && (window.location.pathname === '/obrigado' || window.location.pathname === '/obrigado/')) {
    return <Obrigado />;
  }

  return (
    <LazyMotion features={domAnimation}>
      <BrowserRouter>
        <ScrollToTop />
        <WhatsAppButton />
        <UtmTracker />
        <Suspense fallback={<div className="min-h-screen flex items-center justify-center bg-slate-50"><div className="w-8 h-8 border-4 border-accent border-t-transparent rounded-full animate-spin"></div></div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/obrigado" element={<Obrigado />} />
            <Route path="/politica-de-privacidade" element={<PrivacyPolicy />} />
            <Route path="/termos-de-uso" element={<TermsOfUse />} />
            <Route path="/reserva-dos-passaros-2" element={<ReservaDosPassaros2 />} />
            <Route path="/prime-club-itaborai" element={<PrimeClubItaborai />} />
            <Route path="/flores-de-maio" element={<FloresDeMaio />} />
            <Route path="/solar-da-trindade" element={<SolarDaTrindade />} />
            <Route path="/residencial-florescer" element={<ResidencialFlorescer />} />
            <Route path="/conquista-oceanica" element={<ConquistaOceanica />} />
            <Route path="/minha-casa-minha-vida-itaborai" element={<McmvItaborai />} />
            <Route path="/minha-casa-minha-vida-sao-goncalo" element={<McmvSaoGoncalo />} />
            <Route path="/financiamento-minha-casa-minha-vida" element={<Financiamento />} />
            <Route path="/fgts-minha-casa-minha-vida" element={<FgtsMcmv />} />
            <Route path="/subsidio-minha-casa-minha-vida" element={<SubsidioMcmv />} />
            <Route path="/renda-minha-casa-minha-vida" element={<RendaMcmv />} />
            <Route path="/documentos-minha-casa-minha-vida" element={<DocumentosMcmv />} />
            <Route path="/sobre" element={<Sobre />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </LazyMotion>
  );
}
