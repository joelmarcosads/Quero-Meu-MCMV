function i(a,o){const r="5521965928399";let s="";const e=o.toLowerCase();return e.includes("simulação")||e.includes("simular")?s=`Olá! Vi o *${a}* no site e gostaria de fazer uma simulação de financiamento para ele. 🏦
Vocês conseguem me ajudar a ver os prazos e as condições de entrada?`:e.includes("agora")||e.includes("rápida")?s=`Olá, tudo bem? Gostei muito do *${a}* e quero simular as parcelas dele agora. 🏠💨
Quais dados vocês precisam para fazer esse cálculo rápido para mim?`:e.includes("disponibilidade")||e.includes("valores")||e.includes("consultar")?s=`Olá! Tenho interesse no *${a}*. 🗺️
Gostaria de consultar os valores atuais e saber se ele ainda está disponível. Como posso receber a tabela?`:s=`Olá! Estava navegando nas informações sobre *${a}* e me interessei pela opção "${o}". 🏠
Poderiam me dar mais detalhes sobre isso?`,`https://wa.me/${r}?text=${encodeURIComponent(s)}`}export{i as g};
//# sourceMappingURL=whatsapp-BtDxut1i.js.map
